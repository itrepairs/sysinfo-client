# SysInfo Client

Локальный агент для отображения характеристик ПК на странице [sysinfo.itrepairs.ie](https://sysinfo.itrepairs.ie).

## Использование

1. Скачать `sysinfo.exe` из [Releases](../../releases/latest)
2. Запустить — появится иконка в трее
3. Открыть браузер: https://sysinfo.itrepairs.ie

## Сборка

Автоматически через GitHub Actions при каждом push в `main`.
