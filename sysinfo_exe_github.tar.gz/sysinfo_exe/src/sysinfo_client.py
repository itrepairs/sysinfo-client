#!/usr/bin/env python3
"""
sysinfo_client.py — локальный агент для Windows
Запускает HTTP-сервер на localhost:8765
"""
import http.server
import json
import platform
import subprocess
import socket
import os
import sys
import threading
import time

PORT = 8765

def get_cpu_info():
    cpu_model = "Unknown"
    try:
        import winreg
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
            r"HARDWARE\DESCRIPTION\System\CentralProcessor\0")
        cpu_model = winreg.QueryValueEx(key, "ProcessorNameString")[0].strip()
        winreg.CloseKey(key)
    except:
        cpu_model = platform.processor() or "Unknown"
    try:
        import psutil
        cores = psutil.cpu_count(logical=False)
        threads = psutil.cpu_count(logical=True)
        freq = psutil.cpu_freq()
        freq_str = f"{freq.max/1000:.1f} GHz" if freq and freq.max else ""
    except:
        cores = os.cpu_count() or 0
        threads = cores
        freq_str = ""
    return cpu_model, cores, threads, freq_str

def get_ram_info():
    try:
        import psutil
        mem = psutil.virtual_memory()
        return round(mem.total / (1024**3), 1)
    except:
        return 0

def get_disk_info():
    disks = []
    try:
        import psutil
        for p in psutil.disk_partitions():
            if 'cdrom' in p.opts or p.fstype == '':
                continue
            try:
                usage = psutil.disk_usage(p.mountpoint)
                disks.append({
                    "mount": p.mountpoint,
                    "total": round(usage.total / (1024**3), 1),
                    "used":  round(usage.used  / (1024**3), 1),
                    "percent": usage.percent
                })
            except:
                pass
    except:
        pass
    return disks

def get_gpu_info():
    try:
        result = subprocess.run(
            ['nvidia-smi', '--query-gpu=name,memory.total', '--format=csv,noheader'],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip().split('\n')[0]
    except:
        pass
    try:
        result = subprocess.run(
            ['wmic', 'path', 'win32_VideoController', 'get', 'name'],
            capture_output=True, text=True, timeout=5
        )
        lines = [l.strip() for l in result.stdout.split('\n')
                 if l.strip() and l.strip().lower() != 'name']
        if lines:
            return lines[0]
    except:
        pass
    return "Not detected"

def get_os_info():
    try:
        import winreg
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\Microsoft\Windows NT\CurrentVersion")
        product = winreg.QueryValueEx(key, "ProductName")[0]
        build   = winreg.QueryValueEx(key, "CurrentBuildNumber")[0]
        winreg.CloseKey(key)
        return f"{product} (Build {build})"
    except:
        return f"Windows {platform.release()}"

def get_sysinfo():
    cpu_model, cores, threads, freq = get_cpu_info()
    return {
        "source":      "local",
        "cpu_model":   cpu_model,
        "cpu_cores":   cores,
        "cpu_threads": threads,
        "cpu_freq":    freq,
        "ram_gb":      get_ram_info(),
        "gpu":         get_gpu_info(),
        "os":          get_os_info(),
        "disks":       get_disk_info(),
        "hostname":    socket.gethostname()
    }

class Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path in ('/', '/api/sysinfo'):
            data = json.dumps(get_sysinfo(), ensure_ascii=False)
            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(data.encode('utf-8'))
        else:
            self.send_response(404)
            self.end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, OPTIONS')
        self.end_headers()

    def log_message(self, fmt, *args):
        pass

def run_tray():
    """Трей-иконка через pystray"""
    try:
        import pystray
        from PIL import Image, ImageDraw

        # Рисуем простую иконку
        img = Image.new('RGB', (64, 64), color=(30, 30, 30))
        d = ImageDraw.Draw(img)
        d.ellipse([8, 8, 56, 56], fill=(96, 165, 250))
        d.text((20, 20), "S", fill=(255, 255, 255))

        def on_quit(icon, item):
            icon.stop()
            os._exit(0)

        def on_open(icon, item):
            import webbrowser
            webbrowser.open('https://sysinfo.itrepairs.ie')

        menu = pystray.Menu(
            pystray.MenuItem('Открыть страницу', on_open, default=True),
            pystray.MenuItem('Выход', on_quit)
        )
        icon = pystray.Icon("sysinfo", img, "SysInfo — работает", menu)
        icon.run()
    except Exception as e:
        # Если pystray недоступен — просто ждём
        while True:
            time.sleep(60)

def main():
    server = http.server.HTTPServer(('127.0.0.1', PORT), Handler)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()

    # Трей в отдельном потоке
    run_tray()

if __name__ == '__main__':
    main()
